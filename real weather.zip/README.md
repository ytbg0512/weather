# Simple Weather App
API by OpenWeatherMap

Latest version: 0.1